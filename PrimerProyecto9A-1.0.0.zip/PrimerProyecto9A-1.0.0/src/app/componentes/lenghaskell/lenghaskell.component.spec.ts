import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LenghaskellComponent } from './lenghaskell.component';

describe('LenghaskellComponent', () => {
  let component: LenghaskellComponent;
  let fixture: ComponentFixture<LenghaskellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LenghaskellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LenghaskellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
