import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lenghaskell',
  templateUrl: './lenghaskell.component.html',
  styleUrls: ['./lenghaskell.component.css']
})
export class LenghaskellComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
