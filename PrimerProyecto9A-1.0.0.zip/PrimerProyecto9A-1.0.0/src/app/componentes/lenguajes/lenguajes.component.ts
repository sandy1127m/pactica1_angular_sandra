import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lenguajes',
  templateUrl: './lenguajes.component.html',
  styleUrls: ['./lenguajes.component.css']
})
export class LenguajesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
