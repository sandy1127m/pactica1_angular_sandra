import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes, RouterModule} from '@angular/router';
import { InicioComponent } from './componentes/inicio/inicio.component';
import { LenguajesComponent } from './componentes/lenguajes/lenguajes.component';
import {LenghaskellComponent} from './componentes/lenghaskell/lenghaskell.component';

const routes : Routes = [
  {path: 'inicio', component: InicioComponent},
  {path: 'lenguajes', component: LenguajesComponent},
  {path : 'lenghaskell', component: LenghaskellComponent},
  {path:'**', pathMatch:'full', redirectTo:'inicio'}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports:[RouterModule]
})
export class AppRutasModule { }
