import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { InicioComponent } from './componentes/inicio/inicio.component';
import { LenguajesComponent } from './componentes/lenguajes/lenguajes.component';
import { NavbarComponent } from './componentes/navbar/navbar.component';
import { LenghaskellComponent } from './componentes/lenghaskell/lenghaskell.component';
import { AppRutasModule } from './app-rutas.module';

@NgModule({
  declarations: [
    AppComponent,
    InicioComponent,
    LenguajesComponent,
    NavbarComponent,
    LenghaskellComponent
  ],
  imports: [
    BrowserModule,
    AppRutasModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
